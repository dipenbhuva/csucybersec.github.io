#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main() {

  char foo[] = "This is some text from proc-1";

  printf(" %d  %lx  %lu\n", getpid(), (long unsigned int) foo, strlen(foo)+1);

  sleep(10);
  while(1)
  {
	  printf("\n string is :%s\n",foo);
  }

}
