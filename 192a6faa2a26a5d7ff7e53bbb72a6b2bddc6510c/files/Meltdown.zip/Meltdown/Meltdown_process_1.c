#include <stdio.h>
#include <stdlib.h>
// #include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
int main(int argc, char* argv[]) {

  if (argc != 4) {
    printf("proc-2  pid  addr  length\n");
    exit(1);
  }

  int           pid  = strtol (argv[1], NULL, 10);
  unsigned long addr = strtoul(argv[2], NULL, 16);
  int           len  = strtol (argv[3], NULL, 10);

  char* proc_mem = malloc(50);
  sprintf(proc_mem, "/proc/%d/mem", pid);

  printf("opening %s, address is %ld\n", proc_mem, addr);
  int fd_proc_mem = open(proc_mem, O_RDWR);
  if (fd_proc_mem == -1) {
    printf("Could not open %s\n", proc_mem);
    exit(1);
  }

  char* buf = malloc(len);
  off_t address = addr;
  ptrace(PTRACE_ATTACH, pid, 0, 0);
  waitpid(pid, NULL, 0);
  pread(fd_proc_mem, buf, len, address);
// or
  printf("\nString present is :%s",buf);
  strncpy(buf,"string updated",len);
  pwrite(fd_proc_mem, buf, len, address);
 
  printf("\n updated string is %s:",buf);
  ptrace(PTRACE_DETACH, pid, 0, 0);

  close(fd_proc_mem);
  free(buf);
  free(proc_mem);
}
